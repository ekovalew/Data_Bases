-- Описание БД
-- Данная БД предназначена для хранения информации о книгах, поиска книг или информации о книгах.
-- БД располагает самой необходимой информацией книжной литературы - авторы, серии книг, жанры, поджанры, правообладатель, возрастное ограничение,
-- описание, цитаты. 
-- Помимо этого, в базе предложена дополнительная информация, позволяющая заинтересовать пользователя - страны, в которых происходили действия книги,
-- время (век, часть века(начало, середина и конец)), в котором происходили действия, количество персонажей. Доп. информация распространяется только на художественную литературу.
-- За основу взят сайт Litres.ru.

CREATE DATABASE litres;
use litres;

-- Создание таблиц -----------------------------------------------------
CREATE TABLE users (
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	first_name VARCHAR(100) NOT NULL,
	last_name VARCHAR(100) NOT NULL,
	email VARCHAR(120) NOT NULL,
	phone VARCHAR(30) NOT NULL,
	created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE current_timestamp(),
	UNIQUE KEY email (email),
	UNIQUE KEY phone (phone)
)ENGINE = InnoDB;

DROP TABLE profiles;
CREATE TABLE profiles (
	user_id INT UNSIGNED,
	sex CHAR(1) NOT NULL,
	birthday DATE,
	hometown VARCHAR(100),
	photo VARCHAR(260),
	updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP()
);

CREATE TABLE authors(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	first_name VARCHAR(100) NOT NULL,
	last_name VARCHAR(100) NOT NULL
);
DROP TABLE books;
CREATE TABLE books(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	author_id INT UNSIGNED NOT NULL,
	name VARCHAR(120) NOT NULL,
	series VARCHAR(120),
	date_writing INT NOT NULL,
	ISBN VARCHAR(30) NOT NULL,
	volume INT UNSIGNED NOT NULL,
	rightholder VARCHAR(200) NOT NULL,
	age_limit INT UNSIGNED
);

CREATE TABLE authors_books(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	author_id INT UNSIGNED NOT NULL,
	book_id INT UNSIGNED NOT NULL
);

CREATE TABLE descriptions(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	book_id INT UNSIGNED NOT NULL,
	description VARCHAR(1000) NOT NULL
);

CREATE TABLE genres(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	genre VARCHAR(100) NOT NULL
);

CREATE TABLE subgenres(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	genre_id INT UNSIGNED NOT NULL,
	subgenre VARCHAR(200) NOT NULL
);

DROP TABLE reviews;
CREATE TABLE reviews(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	book_id INT UNSIGNED NOT NULL,
	user_id INT UNSIGNED,
	review VARCHAR(2000) NOT NULL
);

DROP TABLE assessments;
CREATE TABLE assessments(
	assessment INT(2) UNSIGNED NOT NULL PRIMARY KEY
);

DROP TABLE rating;
CREATE TABLE rating(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	user_id INT UNSIGNED,
	book_id INT UNSIGNED NOT NULL,
	assessment_id INT UNSIGNED NOT NULL
);

CREATE TABLE countries_books(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	book_id INT UNSIGNED NOT NULL,
	country VARCHAR(100) NOT NULL
);

DROP TABLE century;
CREATE TABLE century(
	century INT PRIMARY KEY
);

DROP TABLE books_century;
CREATE TABLE books_century(
	book_id INT UNSIGNED,
	century_id INT
);

CREATE TABLE books_decada(
	book_id INT UNSIGNED,
	decada INT UNSIGNED NOT NULL
);

CREATE TABLE books_genres(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	book_id INT UNSIGNED NOT NULL,
	genre_id INT UNSIGNED NOT NULL
);

CREATE TABLE books_subgenres(
	id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	book_id INT UNSIGNED NOT NULL,
	subgenre_id INT UNSIGNED NOT NULL
);

CREATE TABLE persons(
	book_id INT UNSIGNED,
	count_persons INT UNSIGNED
);
-- ------------------------------------------------------------------------

-- Внешние ключи ----------------------------------------------------------
ALTER TABLE authors_books
	ADD CONSTRAINT authors_books_author_id_fk
		FOREIGN KEY (author_id) REFERENCES authors(id)
			ON DELETE CASCADE;
ALTER TABLE authors_books
	ADD CONSTRAINT authors_books_book_id_fk
		FOREIGN KEY (book_id) REFERENCES books(id)
			ON DELETE CASCADE;

ALTER TABLE books_century
	ADD CONSTRAINT books_century_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;
ALTER TABLE books_century
	ADD CONSTRAINT books_century_century_id_fk
		FOREIGN KEY(century_id) REFERENCES century(century)
			ON DELETE SET NULL;

ALTER TABLE books_decada
	ADD CONSTRAINT books_decada_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;
		
ALTER TABLE countries_books
	ADD CONSTRAINT countries_books_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;
		
ALTER TABLE descriptions
	ADD CONSTRAINT descriptions_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;

ALTER TABLE profiles
	ADD CONSTRAINT prfiles_user_id_fk
		FOREIGN KEY(user_id) REFERENCES users(id)
			ON DELETE SET NULL;
		
ALTER TABLE rating
	ADD CONSTRAINT rating_user_id_fk
		FOREIGN KEY(user_id) REFERENCES users(id)
			ON DELETE SET NULL,
	ADD CONSTRAINT rating_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE,
	ADD CONSTRAINT rating_assessment_id_fk
		FOREIGN KEY(assessment_id) REFERENCES assessments(assessment)
			ON DELETE CASCADE;

ALTER TABLE reviews
	ADD CONSTRAINT reviews_user_id_fk
		FOREIGN KEY(user_id) REFERENCES users(id)
			ON DELETE SET NULL,
	ADD CONSTRAINT reviews_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;
	
ALTER TABLE subgenres
	ADD CONSTRAINT subgenres_genre_id_fk
		FOREIGN KEY(genre_id) REFERENCES genres(id)
			ON DELETE CASCADE;
	
ALTER TABLE books_genres
	ADD CONSTRAINT books_genres_genre_id_fk
		FOREIGN KEY(genre_id) REFERENCES genres(id)
			ON DELETE CASCADE,
	ADD CONSTRAINT books_genres_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;
		
ALTER TABLE books_subgenres
	ADD CONSTRAINT books_subgenres_genre_id_fk
		FOREIGN KEY(subgenre_id) REFERENCES subgenres(id)
			ON DELETE CASCADE,
	ADD CONSTRAINT books_subgenres_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;

ALTER TABLE persons
	ADD CONSTRAINT persons_book_id_fk
		FOREIGN KEY(book_id) REFERENCES books(id)
			ON DELETE CASCADE;
-- ------------------------------------------------------------

-- Индексы ----------------------------------------------------

		
		
-- ------------------------------------------------------------

-- Наполнение БД ----------------------------------------------
-- users-----
use litres;
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (1, 'Mallie', 'Blick', 'lockman.mafalda@example.org', '610-310-9772x82168', '2000-11-04 12:26:03', '2019-11-15 10:44:43');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (2, 'Brandyn', 'Zulauf', 'xhilpert@example.net', '(121)589-2054', '2013-06-19 18:53:00', '2011-08-18 11:01:07');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (3, 'Michale', 'Boyle', 'cecilia95@example.com', '(882)494-1203x06512', '1994-12-08 22:12:41', '2016-01-04 05:57:15');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (4, 'Liliane', 'Franecki', 'lnolan@example.org', '08814160323', '2008-02-12 15:54:26', '2006-09-03 12:36:51');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (5, 'Sydney', 'Kihn', 'emiliano.ritchie@example.org', '(804)215-0665x66246', '2000-07-12 23:22:53', '1996-09-16 09:11:40');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (6, 'Hadley', 'Anderson', 'roob.gaston@example.org', '973-815-1204x4488', '2014-01-02 19:30:02', '2000-03-26 15:35:41');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (7, 'Evelyn', 'Jenkins', 'georgianna95@example.org', '+51(1)6188632850', '1996-06-19 12:37:20', '1977-07-16 08:56:12');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (8, 'Zoey', 'Breitenberg', 'cgottlieb@example.com', '1-452-671-4443x583', '1976-04-01 17:48:42', '2000-12-17 12:31:47');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (9, 'Meredith', 'Goyette', 'cordell.rempel@example.org', '841-451-8292x949', '1970-04-01 20:53:08', '2005-06-06 14:23:51');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (10, 'Francisco', 'Ryan', 'lupe39@example.net', '655.525.1681', '1980-01-03 09:11:35', '2006-12-03 05:35:10');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (11, 'Florida', 'Purdy', 'xkonopelski@example.com', '918.347.3882', '1978-05-26 01:10:32', '1976-12-03 00:07:11');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (12, 'Aubrey', 'Miller', 'kozey.alan@example.net', '1-247-132-1498x766', '2011-08-05 09:33:04', '1994-02-12 09:57:49');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (13, 'Marshall', 'Altenwerth', 'fredy31@example.com', '030.464.2060x642', '2005-10-10 18:30:42', '1997-02-13 22:02:26');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (14, 'Joana', 'Cassin', 'smitham.nick@example.org', '(578)594-1804', '1978-10-05 11:09:49', '1989-02-13 01:54:27');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (15, 'Michelle', 'Brown', 'aliyah.stroman@example.net', '006-059-7090', '1999-08-17 06:34:44', '1979-03-27 13:59:50');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (16, 'Antonina', 'Batz', 'frances.kassulke@example.com', '101.529.2350', '1981-06-10 14:48:25', '1979-10-25 10:12:37');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (17, 'Rose', 'Reilly', 'alicia90@example.org', '1-180-856-2484x1952', '2002-05-14 22:06:07', '1976-05-22 19:55:34');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (18, 'Juanita', 'Konopelski', 'zrodriguez@example.net', '(873)575-1983', '1975-07-19 08:50:18', '2008-08-07 17:31:39');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (19, 'Marcelina', 'Davis', 'hegmann.luther@example.org', '1-950-345-7000x9247', '2001-01-05 23:05:47', '2008-02-04 02:00:31');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (20, 'Sigurd', 'Corkery', 'henri.luettgen@example.org', '1-452-677-9276x70147', '1976-10-23 04:12:04', '1975-06-19 09:51:07');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (21, 'Zelma', 'Blick', 'schulist.dion@example.org', '1-419-835-3780', '1978-10-11 15:06:18', '2015-10-31 13:07:03');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (22, 'Tressa', 'Kuhic', 'feil.sidney@example.com', '1-322-315-1692x196', '2005-05-20 00:01:11', '1992-02-13 23:35:22');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (23, 'Evie', 'Roberts', 'vincenza58@example.org', '1-198-186-5662', '2012-02-04 05:11:37', '1981-05-31 11:23:21');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (24, 'Elizabeth', 'Kulas', 'vincenza.turner@example.org', '105.639.4643x85202', '2010-05-13 23:08:31', '1997-07-28 17:42:52');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (25, 'Jordi', 'Kuphal', 'ursula70@example.net', '868.930.1561x166', '2008-03-15 13:21:41', '2004-02-16 06:48:39');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (26, 'Fabiola', 'O\'Conner', 'murphy.lorenzo@example.org', '175-965-5005', '1975-07-11 14:42:20', '2013-10-08 06:18:41');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (27, 'Clyde', 'Dickinson', 'adolphus.hansen@example.org', '083-092-1968', '1987-10-16 07:40:34', '1978-04-27 02:42:19');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (28, 'Lolita', 'Flatley', 'to\'reilly@example.org', '+70(7)0026587483', '2000-04-22 17:58:04', '1973-12-28 15:57:24');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (29, 'Celine', 'Kozey', 'zcorwin@example.net', '+87(6)1310450083', '2012-05-11 03:43:46', '1977-10-30 16:33:40');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (30, 'Carmine', 'Beatty', 'schmeler.demetrius@example.org', '457-878-8434', '1981-11-04 11:45:01', '1984-06-13 08:15:00');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (31, 'Russ', 'Lueilwitz', 'aschimmel@example.com', '1-463-766-9213x867', '1982-01-22 16:00:43', '1984-12-10 00:20:36');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (32, 'Bernie', 'Feeney', 'brad.pagac@example.net', '034-157-3291x788', '2003-10-01 17:07:53', '2016-09-20 05:07:53');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (33, 'Neal', 'Halvorson', 'bell59@example.org', '06135355917', '2003-12-06 05:51:27', '1992-01-11 14:41:04');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (34, 'Marion', 'Baumbach', 'o\'reilly.dino@example.net', '066-011-2593', '2014-05-21 13:56:41', '1987-06-18 18:50:24');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (35, 'Kobe', 'Pfeffer', 'orippin@example.org', '03072723963', '2011-10-02 12:42:53', '1976-12-30 18:24:57');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (36, 'Devin', 'Leuschke', 'kariane34@example.com', '1-096-635-5477', '1992-06-09 20:39:45', '1999-06-18 09:24:41');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (37, 'Mozelle', 'Raynor', 'adolphus10@example.net', '(956)195-6871x6752', '2011-06-08 18:38:01', '1994-08-11 01:51:11');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (38, 'Elisa', 'Gleason', 'joanne.bauch@example.com', '04618685631', '2000-03-08 19:45:37', '1990-02-08 08:17:17');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (39, 'Rhea', 'Donnelly', 'adell.corkery@example.net', '558-647-5157', '1981-07-10 09:20:26', '2005-07-01 06:33:53');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (40, 'Roy', 'Boehm', 'eloisa53@example.com', '174-210-8862x536', '2005-05-22 16:41:46', '1983-09-19 13:14:46');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (41, 'Makenna', 'Green', 'jerrod.sawayn@example.net', '808.744.8088x0182', '1992-11-12 09:46:39', '2012-01-10 13:27:01');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (42, 'Amparo', 'Huels', 'qgraham@example.net', '879-078-8431', '1972-06-06 04:39:39', '2003-12-28 00:39:05');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (43, 'Madge', 'Muller', 'qdickens@example.org', '(670)019-6573x7471', '1992-02-28 19:06:11', '1971-06-14 12:14:19');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (44, 'D\'angelo', 'Bogisich', 'jean.davis@example.org', '141-461-8561x47380', '1986-12-25 01:01:45', '2009-01-12 14:54:16');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (45, 'Janet', 'Botsford', 'znienow@example.net', '07177574111', '1988-03-15 21:20:15', '2002-01-04 11:09:34');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (46, 'Vicky', 'Schowalter', 'nicolette19@example.org', '987.699.5575', '2004-04-10 17:04:01', '1977-01-27 07:10:14');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (47, 'Edyth', 'Prohaska', 'igoyette@example.net', '+15(6)0060025108', '1979-02-02 02:15:23', '2016-08-15 19:23:59');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (48, 'Ofelia', 'Emmerich', 'nathaniel02@example.com', '123-132-2265x4314', '2013-10-20 21:35:31', '1981-10-09 07:45:23');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (49, 'Orville', 'Gottlieb', 'gerda.terry@example.org', '(924)964-2364x0874', '2019-09-27 05:58:47', '1993-05-10 19:33:42');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (50, 'Kariane', 'Keebler', 'dickinson.enrique@example.com', '314-467-9332x75945', '2008-07-21 12:58:01', '1983-10-30 02:16:18');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (51, 'Alf', 'Keeling', 'janiya.waelchi@example.net', '(278)867-1946x210', '1970-07-08 23:50:01', '1985-01-01 22:15:47');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (52, 'Onie', 'Borer', 'murphy.laverna@example.com', '406.497.3070x79964', '1983-08-17 09:47:56', '1987-05-13 06:21:01');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (53, 'Rodolfo', 'Armstrong', 'lon.bernier@example.net', '051-045-3723x3128', '1980-12-28 08:50:06', '2013-12-08 06:25:20');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (54, 'Ansel', 'Morar', 'kschmeler@example.net', '570-159-3724x80814', '2001-12-10 07:03:21', '2011-02-16 18:29:51');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (55, 'Edd', 'DuBuque', 'jterry@example.net', '(220)376-0509x82713', '1971-09-24 13:22:54', '1983-11-14 23:49:25');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (56, 'Otto', 'Kautzer', 'will.candelario@example.com', '886.222.0459x3390', '1991-05-02 00:19:35', '1995-02-10 23:29:56');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (57, 'Duncan', 'Koelpin', 'shanel55@example.org', '333.012.4692x9873', '2015-09-10 13:50:07', '1971-11-11 09:37:55');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (58, 'Asa', 'Denesik', 'leuschke.bell@example.org', '+90(9)1764262563', '1996-06-11 21:43:43', '2005-08-17 14:45:54');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (59, 'Devin', 'Hermann', 'twiegand@example.com', '(581)741-6384x601', '1978-09-05 10:48:07', '2003-01-28 06:55:30');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (60, 'Andrew', 'Lowe', 'sammie25@example.org', '+56(7)1158468709', '1979-06-17 15:24:56', '1980-10-13 01:14:20');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (61, 'Otto', 'Labadie', 'augustine.collins@example.com', '(807)491-2625x7032', '1989-04-08 07:26:39', '2018-08-07 04:34:36');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (62, 'Randi', 'Borer', 'heaven.rau@example.com', '1-949-262-3597x629', '2013-01-07 05:31:27', '1980-02-22 09:25:43');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (63, 'Wanda', 'Huel', 'savanah14@example.org', '1-731-442-5437x74010', '2016-08-15 04:28:48', '1980-04-18 05:38:19');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (64, 'Isabell', 'Batz', 'romaine68@example.com', '1-898-490-7245x5140', '1986-02-27 07:24:56', '2004-04-29 00:16:52');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (65, 'Carson', 'Turcotte', 'glover.brenda@example.net', '1-213-043-9295', '1971-06-14 20:55:21', '1989-01-22 07:28:25');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (66, 'Kaya', 'Cartwright', 'marina38@example.net', '588.521.1884', '2019-09-02 22:40:56', '1971-05-13 11:25:14');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (67, 'Adeline', 'Rowe', 'schamberger.marcelo@example.org', '545.163.2460x33291', '1977-01-28 20:07:17', '2011-10-07 02:20:42');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (68, 'Micaela', 'Hahn', 'mwest@example.org', '289-982-8073x0330', '1996-09-29 06:13:55', '2013-12-18 15:20:41');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (69, 'Rocky', 'Yundt', 'jarvis.runte@example.org', '05434409252', '2005-12-08 19:45:10', '1973-06-14 17:40:32');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (70, 'Annie', 'Jacobs', 'tamara.larson@example.com', '868.201.6181x68808', '1993-12-30 16:38:21', '1991-09-14 10:04:37');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (71, 'Octavia', 'Jenkins', 'ekemmer@example.org', '257.580.9367', '2008-01-23 04:47:36', '1976-10-05 09:27:12');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (72, 'Keven', 'Daugherty', 'quincy.yost@example.org', '06026660778', '1975-02-18 06:45:12', '2015-12-23 22:49:28');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (73, 'Alia', 'Mayer', 'xavier.considine@example.org', '+29(7)1999905696', '2019-10-17 16:49:46', '1971-08-02 23:36:08');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (74, 'Stephan', 'Lynch', 'kaley.brown@example.org', '759-988-1513x020', '1986-12-17 06:38:01', '1995-11-28 13:44:18');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (75, 'Carol', 'Lehner', 'hane.clement@example.com', '600-675-2394', '2007-10-03 22:50:16', '2020-01-04 11:30:23');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (76, 'Gino', 'Bauch', 'ganderson@example.com', '1-499-165-5514x4332', '1975-04-07 00:07:01', '2008-05-11 03:31:34');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (77, 'Elizabeth', 'Jones', 'gflatley@example.net', '1-882-859-5107x6007', '2005-11-20 15:53:29', '2006-06-13 09:47:41');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (78, 'Aracely', 'Abernathy', 'neoma68@example.org', '+64(7)4779293216', '1986-03-10 16:08:20', '2015-05-27 00:45:04');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (79, 'Alexzander', 'Kunde', 'clueilwitz@example.com', '+08(8)8479162983', '2013-08-13 10:16:12', '1985-09-29 02:08:49');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (80, 'Lilly', 'McDermott', 'utorphy@example.org', '1-522-988-1419', '1978-02-23 10:25:18', '2017-09-04 23:32:20');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (81, 'Meagan', 'Kirlin', 'burley11@example.com', '003.009.9042', '1977-10-15 03:15:25', '1974-01-02 14:31:32');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (82, 'Chaz', 'Kilback', 'rwintheiser@example.net', '126.305.9580', '1981-09-06 10:25:15', '1984-05-17 02:28:40');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (83, 'Leopoldo', 'Lowe', 'kody.hauck@example.org', '+80(2)7917512531', '1970-08-22 05:49:08', '1995-08-11 12:06:28');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (84, 'Maxie', 'Welch', 'ygrady@example.com', '164-738-4843', '2007-08-31 01:14:19', '2012-12-19 07:24:19');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (85, 'Quincy', 'Spencer', 'ferry.shyann@example.com', '435.351.8992', '1975-12-12 22:02:09', '1999-10-12 04:19:10');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (86, 'Pink', 'Watsica', 'mherman@example.net', '1-898-211-6619x6983', '2016-03-20 15:08:47', '2012-12-08 17:33:31');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (87, 'Caterina', 'Lind', 'donnelly.lila@example.net', '(514)577-2467x79847', '1973-09-24 06:22:07', '1979-04-06 12:06:05');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (88, 'Jacinthe', 'Stamm', 'ed.o\'conner@example.net', '1-833-496-1254x54833', '1987-03-29 09:54:30', '1988-01-19 03:05:00');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (89, 'Aron', 'Moore', 'mayer.burley@example.org', '+17(5)3587737046', '2008-06-12 00:55:23', '1976-03-21 01:25:27');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (90, 'Audie', 'D\'Amore', 'brekke.dahlia@example.com', '1-660-679-1086', '1982-11-28 21:08:39', '2001-02-06 14:01:58');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (91, 'Meredith', 'Swift', 'kohler.elenor@example.com', '743-317-0808', '1981-07-25 22:09:31', '1990-07-28 21:05:21');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (92, 'Hobart', 'Hintz', 'toby.greenfelder@example.com', '(767)845-1052', '2010-08-30 18:58:56', '2018-04-18 11:30:49');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (93, 'Darlene', 'Hahn', 'jacobson.ryan@example.net', '(982)861-6456x68691', '2007-01-22 10:50:55', '2019-07-28 19:02:54');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (94, 'Alvah', 'Mayert', 'katarina.dicki@example.com', '1-732-733-5509', '1972-02-07 13:52:24', '2013-12-16 09:50:29');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (95, 'Elton', 'Wilderman', 'noemie.effertz@example.net', '1-572-665-9483x6026', '2003-04-11 05:26:13', '2009-06-16 02:02:13');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (96, 'Damaris', 'Cartwright', 'bhermann@example.net', '06768282164', '1979-07-21 23:26:56', '1995-03-11 03:33:55');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (97, 'Darrel', 'Herman', 'pconroy@example.org', '286-301-5268', '1974-02-25 02:49:28', '1994-12-26 00:45:33');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (98, 'Okey', 'Lehner', 'tomasa.bergstrom@example.com', '1-514-477-4543x354', '2016-01-22 00:10:35', '2012-01-27 23:48:14');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (99, 'Tressa', 'Rau', 'beatrice.witting@example.org', '1-036-253-7824', '2004-06-19 06:30:45', '1975-11-09 23:47:06');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `phone`, `created_at`, `updated_at`) VALUES (100, 'Ciara', 'Mosciski', 'brekke.braulio@example.com', '(159)673-4007x86504', '2005-03-31 04:55:02', '1991-04-30 16:17:16');
		
-- profiles-----
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (1, '', '2013-12-19', 'North Elmore', 'http://lorempixel.com/640/480/', '2007-02-15 05:35:06');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (2, '', '1992-08-04', 'Port Erwin', 'http://lorempixel.com/640/480/', '2003-05-23 22:24:00');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (3, '', '1995-11-19', 'West Ryder', 'http://lorempixel.com/640/480/', '1978-09-03 03:17:38');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (4, '', '2002-09-08', 'Port Merle', 'http://lorempixel.com/640/480/', '2001-01-06 14:14:12');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (5, '', '2011-10-18', 'Lolaton', 'http://lorempixel.com/640/480/', '1991-01-11 02:03:47');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (6, '', '1993-06-03', 'Shayneborough', 'http://lorempixel.com/640/480/', '1970-01-31 00:01:07');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (7, '', '2017-04-30', 'Bruenmouth', 'http://lorempixel.com/640/480/', '2005-04-21 02:54:06');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (8, '', '1979-05-12', 'Port Dante', 'http://lorempixel.com/640/480/', '2002-03-25 01:40:56');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (9, '', '1983-07-17', 'Corneliustown', 'http://lorempixel.com/640/480/', '1986-04-21 09:13:23');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (10, '', '1970-09-22', 'Port Sabrynamouth', 'http://lorempixel.com/640/480/', '1974-02-15 00:44:40');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (11, '', '2019-06-09', 'Dickiview', 'http://lorempixel.com/640/480/', '1975-03-27 04:51:19');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (12, '', '1991-07-26', 'Caliburgh', 'http://lorempixel.com/640/480/', '1998-10-17 01:56:26');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (13, '', '2015-03-06', 'Goodwinstad', 'http://lorempixel.com/640/480/', '1975-11-01 03:49:49');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (14, '', '1974-01-21', 'Huelland', 'http://lorempixel.com/640/480/', '1980-05-24 17:23:06');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (15, '', '1992-02-06', 'North Gregbury', 'http://lorempixel.com/640/480/', '2006-05-17 12:52:24');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (16, '', '1989-06-13', 'Trompburgh', 'http://lorempixel.com/640/480/', '2003-04-08 11:57:07');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (17, '', '1980-06-30', 'Lake Duanefort', 'http://lorempixel.com/640/480/', '1989-12-12 01:25:28');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (18, '', '2001-12-28', 'New Nilsmouth', 'http://lorempixel.com/640/480/', '1993-01-03 10:36:36');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (19, '', '1997-07-12', 'East Emilianoville', 'http://lorempixel.com/640/480/', '2019-09-06 22:50:38');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (20, '', '1992-07-11', 'Chetmouth', 'http://lorempixel.com/640/480/', '2000-04-14 02:44:11');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (21, '', '1974-10-12', 'New Gertrude', 'http://lorempixel.com/640/480/', '1975-12-13 01:24:23');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (22, '', '1997-01-16', 'Bashirianton', 'http://lorempixel.com/640/480/', '2009-05-05 10:27:06');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (23, '', '2004-08-01', 'Parisianside', 'http://lorempixel.com/640/480/', '1988-07-06 06:53:13');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (24, '', '1990-12-30', 'Gleasonmouth', 'http://lorempixel.com/640/480/', '1981-08-08 14:37:25');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (25, '', '1974-11-13', 'Lake Junius', 'http://lorempixel.com/640/480/', '1976-06-17 14:21:12');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (26, '', '2009-05-04', 'Patfort', 'http://lorempixel.com/640/480/', '1988-01-09 17:46:50');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (27, '', '1996-04-30', 'Alyceborough', 'http://lorempixel.com/640/480/', '1998-06-10 04:16:14');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (28, '', '1973-02-12', 'West Stephanie', 'http://lorempixel.com/640/480/', '2001-12-02 23:53:54');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (29, '', '1991-02-03', 'Croninside', 'http://lorempixel.com/640/480/', '1975-02-16 06:48:07');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (30, '', '1988-05-05', 'New Loren', 'http://lorempixel.com/640/480/', '1996-01-02 03:42:17');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (31, '', '1978-02-09', 'East Ayana', 'http://lorempixel.com/640/480/', '1972-06-29 14:19:30');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (32, '', '2013-07-27', 'Lake Anneshire', 'http://lorempixel.com/640/480/', '2007-03-05 18:20:47');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (33, '', '2001-05-21', 'North Nilstown', 'http://lorempixel.com/640/480/', '1993-06-28 11:14:37');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (34, '', '2008-03-13', 'West Johathan', 'http://lorempixel.com/640/480/', '2005-12-28 16:40:00');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (35, '', '1976-11-16', 'Myraberg', 'http://lorempixel.com/640/480/', '2010-11-22 20:40:33');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (36, '', '2016-12-06', 'Patmouth', 'http://lorempixel.com/640/480/', '1970-07-29 11:36:26');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (37, '', '1996-12-10', 'Faybury', 'http://lorempixel.com/640/480/', '1975-11-23 23:39:16');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (38, '', '2008-10-19', 'South Okey', 'http://lorempixel.com/640/480/', '1993-03-14 18:54:39');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (39, '', '2004-10-13', 'Annabellemouth', 'http://lorempixel.com/640/480/', '1974-04-07 02:12:19');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (40, '', '1984-02-22', 'East Shayne', 'http://lorempixel.com/640/480/', '1974-05-22 03:36:31');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (41, '', '2002-02-07', 'Ryantown', 'http://lorempixel.com/640/480/', '1985-05-03 22:52:56');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (42, '', '2001-02-03', 'North Skyla', 'http://lorempixel.com/640/480/', '2007-02-26 16:28:14');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (43, '', '2004-04-03', 'Bashirianberg', 'http://lorempixel.com/640/480/', '1988-11-03 14:55:26');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (44, '', '2000-03-23', 'West Leannaborough', 'http://lorempixel.com/640/480/', '2006-09-01 00:22:58');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (45, '', '2013-08-13', 'Joelleton', 'http://lorempixel.com/640/480/', '1971-04-03 20:34:21');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (46, '', '1986-10-26', 'Bostad', 'http://lorempixel.com/640/480/', '1981-12-16 17:14:09');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (47, '', '1971-02-05', 'New Scot', 'http://lorempixel.com/640/480/', '1980-10-13 14:02:57');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (48, '', '1979-07-21', 'Grovermouth', 'http://lorempixel.com/640/480/', '2005-03-06 10:42:57');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (49, '', '1974-09-08', 'North Bernieport', 'http://lorempixel.com/640/480/', '2008-04-22 17:40:46');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (50, '', '1974-10-10', 'Lake Eldorastad', 'http://lorempixel.com/640/480/', '1983-02-10 19:58:08');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (51, '', '2006-09-10', 'Lindseyfort', 'http://lorempixel.com/640/480/', '1978-02-22 09:39:15');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (52, '', '2016-09-30', 'Shieldsfurt', 'http://lorempixel.com/640/480/', '2011-07-16 15:08:58');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (53, '', '1988-08-09', 'New Sherwoodport', 'http://lorempixel.com/640/480/', '1991-07-30 00:14:06');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (54, '', '2008-04-05', 'West Emile', 'http://lorempixel.com/640/480/', '1979-02-03 22:48:04');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (55, '', '1988-10-30', 'Lake Libbie', 'http://lorempixel.com/640/480/', '2019-08-04 22:44:36');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (56, '', '1977-02-10', 'Savanahtown', 'http://lorempixel.com/640/480/', '1999-09-26 19:21:08');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (57, '', '2017-11-30', 'Kirafurt', 'http://lorempixel.com/640/480/', '2011-10-22 10:27:57');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (58, '', '2000-01-16', 'Howeside', 'http://lorempixel.com/640/480/', '1971-12-20 23:13:45');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (59, '', '1998-10-09', 'McDermottton', 'http://lorempixel.com/640/480/', '2003-01-06 22:53:51');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (60, '', '1974-01-24', 'Lake Sylviatown', 'http://lorempixel.com/640/480/', '1995-06-21 15:33:59');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (61, '', '2007-07-13', 'Lake Wyman', 'http://lorempixel.com/640/480/', '1988-10-19 12:07:57');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (62, '', '1973-04-27', 'South Aldamouth', 'http://lorempixel.com/640/480/', '1989-04-05 12:16:11');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (63, '', '1982-05-02', 'Wardside', 'http://lorempixel.com/640/480/', '2015-09-27 20:49:12');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (64, '', '1982-08-24', 'Lake Arlie', 'http://lorempixel.com/640/480/', '1994-11-11 17:30:57');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (65, '', '2018-06-27', 'Leonardside', 'http://lorempixel.com/640/480/', '1976-06-16 02:16:07');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (66, '', '1984-02-24', 'Skylartown', 'http://lorempixel.com/640/480/', '2008-08-07 19:19:37');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (67, '', '2003-02-08', 'Leuschketon', 'http://lorempixel.com/640/480/', '2017-04-04 10:56:46');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (68, '', '1992-03-20', 'Alexandrechester', 'http://lorempixel.com/640/480/', '1988-03-02 02:23:58');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (69, '', '1997-08-23', 'West Georgiana', 'http://lorempixel.com/640/480/', '1987-05-24 16:29:16');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (70, '', '2018-03-06', 'Ankundingbury', 'http://lorempixel.com/640/480/', '1995-08-05 16:31:45');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (71, '', '2007-04-18', 'Hartmannbury', 'http://lorempixel.com/640/480/', '2004-05-12 03:00:55');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (72, '', '1976-01-22', 'Jastton', 'http://lorempixel.com/640/480/', '1988-05-14 14:45:51');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (73, '', '1993-03-29', 'Fritschtown', 'http://lorempixel.com/640/480/', '1989-05-07 01:36:31');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (74, '', '1975-11-27', 'Bonitaville', 'http://lorempixel.com/640/480/', '1971-09-24 07:20:22');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (75, '', '2015-12-11', 'New Wyattchester', 'http://lorempixel.com/640/480/', '2017-06-02 00:38:05');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (76, '', '1990-05-28', 'New Clemmie', 'http://lorempixel.com/640/480/', '1977-12-28 14:16:50');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (77, '', '2003-03-23', 'Port Laurianne', 'http://lorempixel.com/640/480/', '1991-08-25 11:11:56');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (78, '', '1972-02-01', 'Feliciaview', 'http://lorempixel.com/640/480/', '1998-12-05 11:39:13');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (79, '', '1999-10-24', 'Lake Merle', 'http://lorempixel.com/640/480/', '1985-09-30 09:22:32');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (80, '', '2011-09-28', 'New Destanyland', 'http://lorempixel.com/640/480/', '1980-05-13 14:13:14');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (81, '', '1999-10-15', 'Lake Adrianna', 'http://lorempixel.com/640/480/', '2010-06-27 16:40:34');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (82, '', '1998-07-05', 'Thielview', 'http://lorempixel.com/640/480/', '1981-05-06 22:38:33');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (83, '', '1976-12-04', 'South Clemens', 'http://lorempixel.com/640/480/', '2008-05-23 16:55:14');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (84, '', '1981-09-14', 'South Neha', 'http://lorempixel.com/640/480/', '1984-01-02 21:48:57');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (85, '', '1971-07-16', 'Jerrymouth', 'http://lorempixel.com/640/480/', '2018-06-15 00:55:23');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (86, '', '1984-03-11', 'Pearlieburgh', 'http://lorempixel.com/640/480/', '2004-03-29 11:46:54');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (87, '', '2005-06-12', 'West Reinholdside', 'http://lorempixel.com/640/480/', '2012-04-10 20:43:41');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (88, '', '2008-07-29', 'New Ofeliamouth', 'http://lorempixel.com/640/480/', '2004-02-28 17:34:23');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (89, '', '2001-10-13', 'North Sonya', 'http://lorempixel.com/640/480/', '2018-11-20 16:44:07');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (90, '', '1988-10-16', 'Wizamouth', 'http://lorempixel.com/640/480/', '1992-08-17 07:29:31');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (91, '', '2003-07-04', 'North Marty', 'http://lorempixel.com/640/480/', '2015-11-17 11:19:16');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (92, '', '1984-11-19', 'Mariahstad', 'http://lorempixel.com/640/480/', '2013-10-14 10:26:20');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (93, '', '1996-12-07', 'Port Emeraldchester', 'http://lorempixel.com/640/480/', '1974-03-20 01:40:29');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (94, '', '2001-07-08', 'Rohanchester', 'http://lorempixel.com/640/480/', '2007-12-25 10:42:41');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (95, '', '1980-08-07', 'North Monique', 'http://lorempixel.com/640/480/', '2003-10-26 10:26:42');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (96, '', '1995-11-23', 'Lake Coltborough', 'http://lorempixel.com/640/480/', '1982-12-04 00:26:00');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (97, '', '1977-03-02', 'East Adelachester', 'http://lorempixel.com/640/480/', '1989-10-04 17:00:10');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (98, '', '1987-09-23', 'North Tarachester', 'http://lorempixel.com/640/480/', '1989-07-25 16:25:32');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (99, '', '2004-03-20', 'Melodyport', 'http://lorempixel.com/640/480/', '2011-10-13 22:52:46');
INSERT INTO `profiles` (`user_id`, `sex`, `birthday`, `hometown`, `photo`, `updated_at`) VALUES (100, '', '2017-12-16', 'Lemuelshire', 'http://lorempixel.com/640/480/', '1977-12-16 09:09:03');

CREATE TEMPORARY TABLE sex (sex CHAR(1));
INSERT INTO sex VALUES ('m'), ('f');
UPDATE profiles SET sex = (SELECT sex FROM sex ORDER BY RAND() LIMIT 1);

INSERT INTO assessments VALUES
(1), (2), (3), (4), (5), (6), (7), (8), (9), (10);
INSERT INTO century VALUES
(1), (2), (3), (4), (5), (6), (7), (8), (9), (10), (11), (12), (13), (14), (15), (16), (17), (18), (19), (20), (21), (22), (-1);

INSERT INTO authors(first_name, last_name) VALUES
('Сергей', 'Лукьяненко'),
('Айн', 'Рэнд'),
('Дэн', 'Браун'),
('Чарльз', 'Диккенс'),
('Фёдор', 'Достоевский'),
('Лев', 'Толстой'),
('Томас', 'Манн'),
('Александр', 'Дюма'),
('Эрих Мария', 'Ремарк'),
('Гузель', 'Яхина'),
('Андрей', 'Курпатов'),
('Татьяна', 'Устинова'),
('Стивен', 'Кинг'),
('Олдос', 'Хаксли'),
('Теодор', 'Драйзер'),
('Виктор', 'Пелевин'),
('Евгений', 'Водолазкин'),
('Генри', 'Марш');

INSERT INTO books(author_id, name, series, date_writing, ISBN, volume, rightholder, age_limit) VALUES
(1, 'Квази', 'Кваzи', 2016, '978-5-17-098131-1', 320, 'Издательство АСТ', 16),
(1, 'Черновик', 'Работа над ошибками', 2005, '5-17-033151-2', 360, 'Издательство АСТ', 12),
(1, 'Чистовик', 'Работа над ошибками', 2007, '978-5-17-107192-9', 320, 'Издательство АСТ', 16),
(2, 'Атлант расправил плечи', NULL, 1957, '978-5-9614-2004-3', 1890, 'Альпина Диджитал', 16),
(2, 'Источник', NULL, 1957, '978-5-9614-2011-1', 1110, 'Альпина Диджитал', 16),
(3, 'Код да Винчи', 'Роберт Лэнгдон', 2003, '5-17-038831-4', 560, 'Издательство АСТ', 16),
(3, 'Ангелы и Демоны', 'Роберт Лэнгдон', 2000, '5-17-021652-1', 670, 'Издательство АСТ', 18),
(3, 'Утраченный символ', 'Роберт Лэнгдон', 2009, '978-5-17-064155-0', 560, 'Издательство АСТ', 16),
(3, 'Инферно', 'Роберт Лэнгдон', 2013, '978-5-17-098858-7', 550, 'Издательство АСТ', 16),
(3, 'Происхождение', 'Роберт Лэнгдон', 2017, '978-5-17-106150-0', 530, 'Издательство АСТ', 16),
(4, 'Большие надежды', NULL, 1861, '978-5-17-069501-0', 610, 'Издательство АСТ', 12),
(4, 'Жизнь Дэвида Копперфилда, рассказанная им самим', NULL, 1850, '978-5-17-104888-4', 1190, 'Издательство АСТ', 16),
(4, 'Лавка древностей', NULL, 1841, '978-5-17-069495-2', 730, 'Издательство АСТ', 12),
(4, 'Домби и сын', NULL, 1848, '978-5-17-070259-6', 1220, 'Издательство АСТ', 0),
(5, 'Идиот', 'Школьная библиотека (Детская литература)', 1868, '978-5-08-005801-1', 920, 'Издательство "Детская литература"', 16),
(5, 'Униженные и оскорбленные', 'Школьная библиотека (Детская литература)', 1861, '5-08-004063-7', 500, 'Издательство "Детская литература"', 12),
(6, 'Война и мир. Том 1', 'Школьная библиотека (Детская литература)', 1869, '978-5-08-004654-4', 570, 'Издательство "Детская литература"', 12),
(6, 'Война и мир. Том 2', 'Школьная библиотека (Детская литература)', 1869, '978-5-08-004654-4', 520, 'Издательство "Детская литература"', 12),
(6, 'Ана Каренина', 'Школьная библиотека (Детская литература)', 1878, '978-5-04-107917-8', 1130, 'Эксмо', 16),
(7, 'Волшебная гора', NULL, 1924, '978-5-17-091774-7', 1200, 'Эксмо', 16),
(8, 'Граф Монте-Кристо', NULL, 1845, '978-5-699-32438-5', 1500, 'Public Domain', 12),
(8, 'Королева Марго', 'Королева Марго', 1843, '978-5-699-31284-9', 680, 'Эксмо', 16),
(9, 'Три товарища', NULL, 1970, '978-5-271-32051-4', 470, 'Издательство АСТ', 16),
(9, 'Жизнь взаймы', NULL, 1961, '978-5-271-32299-0', 240, 'Издательство АСТ', 16),
(9, 'Триумфальная арка', NULL, 1946, '978-5-271-41304-9', 520, 'Издательство АСТ', 12),
(10, 'Зулейха открывает глаза', 'Проза: женский род', 2015, '978-5-17-090436-5', 450, 'Издательство АСТ', 16),
(11, 'Чертоги разума. Убей в себе идиота!', 'Академия смысла', 2018, '978-5-906902-91-7', 330, 'Курпатов А.В.', 16),
(12, 'Земное притяжение', 'Татьяна Устинова. Первая среди лучших', 2017, '978-5-699-99652-0', 310, 'Эксмо', 16),
(13, 'Оно', 'Король на все времена', 1986, '978-5-17-065495-6', 1530, 'Издательство АСТ', 18),
(13, 'Противостояние', NULL, 1978, '978-5-17-076512-6', 1590, 'Издательство АСТ', 16),
(13, 'Сияние', 'Дэнни Торранс', 1977, '978-5-271-41319-3', 560, 'Издательство АСТ', 16),
(13, 'Доктор Сон', 'Дэнни Торранс', 2013, '978-5-17-094700-3', 610, 'Издательство АСТ', 16),
(14, 'О дивный новый мир', 'Эксклюзивная классика (АСТ)', 1932, '978-5-17-086774-5', 220, 'Издательство АСТ', 16),
(14, 'Остров', 'Эксклюзивная классика (АСТ)', 1962, '978-5-17-092444-8', 440, 'Издательство АСТ', 16),
(15, 'Финансист', 'Трилогия желания (новый перевод)', 1912, '978-5-4467-1726-2', 700, 'ФТМ', 16),
(15, 'Американская трагедия', NULL, 1925, '978-5-4467-2707-0', 1150, 'ФТМ', 16),
(15, 'Стоик', 'Трилогия желания', 1947, '978-5-4467-2717-9', 470, 'ФТМ', 16),
(16, 'iPhuck 10', 'Единственный и неповторимый. Виктор Пелевин', 2017, '978-5-04-089394-2', 360, 'Эксмо', 18),
(16, 'S.N.U.F.F.', 'Единственный и неповторимый. Виктор Пелевин', 2011, '978-5-699-53962-8', 440, 'ФТМ', 18),
(17, 'Авиатор', NULL, 2015, '978-5-17-096655-4', 350, 'Издательство АСТ', 16),
(18, 'Не навреди. Истории о жизни, смерти и нейрохирургии', 'Медицина без границ. Книги о тех, кто спасает жизни', 2014, '978-5-699-83020-6', 330, 'Эксмо', 12);

use litres;
INSERT INTO genres(genre) VALUES
	('Детективы'), ('Фэнтези'), ('Классика'), ('Приключения'), ('Научно-популярный'), ('Ужасы');

INSERT INTO subgenres(genre_id, subgenre) VALUES 
(1, 'Зарубежные детективы'), 
(1, 'Отечественные детективы'),
(2, 'Зарубежное фэнтези'), 
(2, 'Отечественное фэнтези'),
(3, 'Зарубежная классика'), 
(3, 'Отечественная классика'),
(4, 'Зарубежные приключения'), 
(4, 'Отечественные приключения'),
(6, 'Зарубежные ужасы'), 
(6, 'Отечественные ужасы');

INSERT INTO books_century VALUES(1, 21), (2, 21), (3, 21), (4, 20), (5, 20), (6, 21), (7, 21), (8, 21), (9, 21), (10, 21), (11, 19), (12, 19),
(13, 19), (14, 19), (15, 19), (16, 19), (17, 19), (18, 19), (19, 19), (20, 20), (21, 19), (22, 19), (23, 20), (24, 20), (25, 20), (26, 21),
(27, 21), (28, 21), (29, 20), (30, 20), (31, 20), (32, 20), (33, 20), (34, 20), (35, 21), (36, 21), (37, 21), (38, 21), (39, 21);

INSERT INTO books_decada VALUES(1, 1), (2, 1), (3, 1), (4, 2), (5, 2), (6, 1), (7, 1), (8, 1), (9, 1), (10, 1), (11, 3), (12, 2),
(13, 2), (14, 2), (15, 3), (16, 3), (17, 3), (18, 3), (19, 3), (20, 1), (21, 2), (22, 2), (23, 3), (24, 2), (25, 2), (26, 1),
(27, 1), (28, 1), (29, 3), (30, 3), (31, 3), (32, 1), (33, 1), (34, 1), (35, 1), (36, 1), (37, 1), (38, 1), (39, 1);
DELETE FROM books_decada;

INSERT INTO books_genres(book_id, genre_id) VALUES(1, 1), (2, 2), (3, 3), (4, 2), (5, 1), (6, 4), (7, 4), (8, 6), (9, 4), (10, 1), (11, 4), (12, 2),
(13, 2), (14, 4), (15, 4), (16, 4), (17, 3), (18, 3), (19, 3), (20, 1), (21, 2), (22, 2), (23, 3), (24, 2), (25, 2), (26, 1),
(27, 1), (28, 1), (29, 6), (30, 3), (31, 6), (32, 1), (33, 1), (34, 1), (35, 2), (36, 3), (37, 4), (38, 1), (39, 1);

INSERT INTO books_subgenres(book_id, subgenre_id) VALUES(1, 1), (2, 2), (3, 3), (4, 2), (5, 9), (6, 4), (7, 8), (8, 6), (9, 4), (10, 7), (11, 4), (12, 2),
(13, 2), (14, 4), (15, 4), (16, 4), (17, 3), (18, 3), (19, 6), (20, 1), (21, 5), (22, 9), (23, 3), (24, 10), (25, 8), (26, 7),
(27, 1), (28, 6), (29, 6), (30, 3), (31, 6), (32, 1), (33, 1), (34, 1), (35, 2), (36, 3), (37, 4), (38, 1), (39, 1);

INSERT INTO descriptions(book_id, description) VALUES
	(1, 'Один плохой полицейский. Один мёртвый полицейский. Одна неделя, чтобы спасти весь мир.'),
	(2, 'В твоей квартире живут чужие люди. Твое место на работе занято другим… Тебя не узнают ни друзья, ни любимая девушка… Тебя стирают из этого мира. Кто?'),
	(3, 'Сначала был «Черновик». Роман, покоривший сердца сотен тысяч любителей фантастики. Теперь человек, стертый из этого мира, сумел разорвать невидимые цепи, привязавшие его к миру иному. Он свободен, но бывшие хозяева по-прежнему охотятся за ним. «Черновик» судьбы написан. Настало время «Чистовика»!'),
	(4, 'К власти в США приходят социалисты и правительство берет курс на «равные возможности», считая справедливым за счет талантливых и состоятельных сделать богатыми никчемных и бесталанных. Гонения на бизнес приводят к разрушению экономики, к тому же один за другим при загадочных обстоятельствах начинают исчезать талантливые люди и лучшие предприниматели. Главные герои романа стальной король Хэнк Риарден и вице-президент железнодорожной компании Дагни Таггерт тщетно пытаются противостоять трагическим событиям. Вместо всеобщего процветания общество погружается в апатию и хаос.'),
	(5, 'На протяжении десятилетий роман «Источник» держится в списке мировых бестселлеров, став классикой для миллионов читателей. Главные герои романа – архитектор Говард Рорк и журналистка Доминик Франкон – отстаивают свободу творческой личности в борьбе с обществом, где ценят «равные возможности» для всех. Вместе и поодиночке, друг с другом и друг против друга, но всегда – наперекор устоям толпы. Они – индивидуалисты, их миссия – творить и преобразовывать мир.'),
	(6, 'Страшное преступление совершается в стенах Лувра: куратор Жан Соньер жестоко убит, на его обнаженном теле начертаны странные знаки, а рядом с его трупом виднеются пурпурные буквы и цифры. В качестве помощника в расследовании полиция приглашает профессора Гарвардского университета по истории культуры и религии Роберта Лэнгдона.'),
	(7, 'Контейнер с опасной антиматерией похищен. И за этим преступлением, по мнению профессора Роберта Лэнгдона, стоит тайный оккультный орден иллюминатов, восставший из небытия. Путем долгих вычислений Лэнгдону удается узнать, что штаб-квартира ордена находится в Ватикане. Теперь ему предстоит как можно скорее приехать в Рим и заняться поисками контейнера, чтобы спасти мир. Но для этого нужно будет разгадать множество сложных загадок. К счастью, профессору Гарвардского университета это под силу.'),
	(8, '«Утраченный символ» – третья книга о приключениях Роберта Лэнгдона. Профессору предстоит прочитать лекцию в Национальном зале статуй Капитолия, но визит принимает неожиданный оборот. Услышав крик из ротонды, он бежит к источнику звука и видит отсеченную руку на деревянном постаменте. И кому, как ни профессору Гарвардского университета, знать, что эта зловещая инсталляция символизирует «Руку Мистерий». И, что еще ужаснее, перстень на отсеченной руке указывает на то, что она принадлежала другу и наставнику Лэнгдона – Питеру. На этот раз профессору предстоит расшифровать утраченное слово и раскрыть тайну масонов, которая может изменить мир.'),
	(9, '…Оказавшись в самом загадочном городе Италии – Флоренции, профессор Лэнгдон, специалист по кодам, символам и истории искусства, неожиданно попадает в водоворот событий, которые способны привести к гибели все человечество … И помешать этому может только разгадка тайны, некогда зашифрованной Данте в строках бессмертной эпической поэмы…'),
	(10, '«Происхождение» – пятая книга американского писателя Дэна Брауна о гарвардском профессоре, специалисте по религиозной символике Роберте Лэнгдоне. В этот раз все начинается с, возможно, одного из наиболее знаковых событий в истории: наконец-то стало известно, откуда произошло человечество. Футуролог Эдмонд Кирш, совершивший невероятное открытие, был всего лишь в шаге от того, чтобы полностью изменить представление современников о мире. Однако его речи не суждено было прозвучать в стенах Музея Гуггенхайма. Ученого убили на глазах гостей. И начался хаос…'),
	(11, 'История Пипа – мальчишки из простой крестьянской семьи, который нежданно-негаданно получил возможность «выбиться в люди» и войти в лучшее лондонское общество, и Эстеллы, которую опекунша – полубезумная аристократка – сделала орудием своей мести, вырастив из нее роковую красавицу, разбивающую мужские сердца, завораживает читателя с первых же страниц, однако обрамляющие ее колоритные и яркие картины викторианского Лондона не уступают ей ни в остроумии, ни в обаянии.'),
	(12, '«Жизнь Дэвида Копперфилда» – поистине самый популярный роман Диккенса. Роман, переведенный на все языки мира, экранизировавшийся десятки раз – и по-прежнему завораживающий читателя своей простотой и совершенством. Это – история молодого человека, готового преодолеть любые преграды, претерпеть любые лишения и ради любви совершить самые отчаянные и смелые поступки. История бесконечно обаятельного Дэвида, гротескно ничтожного Урии и милой прелестной Доры. История, воплотившая в себе очарование «старой доброй Англии», ностальгию по которой поразительным образом испытывают сегодня люди, живущие в разных странах на разных континентах…'),
	(13, 'Один из самых красивых и изысканных романов Чарлза Диккенса, положенный в основу множества фильмов и телесериалов.'),
	(14, 'Роман, в котором он беспощадно обнажает душу ранневикторианского буржуа, лишенного человеческих чувств и одержимого жаждой наживы.'),
	(15, 'Глубокое проникновение в образ каждого персонажа романа Ф.М. Достоевского «Идиот» позволило Владимиру Ерёмину создать настоящий шедевр исполнительского мастерства.'),
	(16, 'Роман о людях, которых «человеческое достоинство оскорблено» (Н. Добролюбов), но которым удается с мужеством и честью выйти из трагической ситуации, не озлобившись, сохранив свою живую душу, свои высокие нравственные идеалы.'),
	(17, 'В книгу вошли первый и второй тома романа «Война и мир» – одного из самых знаменитых произведений литературы XIX века.'),
	(18, 'В книгу вошли первый и второй тома романа «Война и мир» – одного из самых знаменитых произведений литературы XIX века.'),
	(19, '«Анну Каренину» Толстой называл «романом широким и свободным». В основе этого определения пушкинский термин «свободный роман». Не фабульная завершенность положений, а творческая концепция определяет выбор материала и открывает простор для развития сюжетных линий. Роман «широкого дыхания» привлекал Толстого тем, что в «просторную, вместительную раму» без напряжения входило все то новое, необычайное и нужное, что он хотел сказать людям.'),
	(20, '«Волшебная гора» – туберкулезный санаторий в Швейцарских Альпах. Его обитатели вынуждены находиться здесь годами, общаясь с внешним миром лишь редкими письмами и телеграммами. Здесь время течет незаметно, жизнь и смерть утрачивают смысл, а мельчайшие нюансы человеческих отношений, напротив, приобретают болезненную остроту и значимость. Любовь, веселье, дружба, вражда, ревность для обитателей санатория словно отмечены тенью небытия…'),
	(21, 'Сюжет «Графа Монте-Кристо» был почерпнут Александром Дюма из архивов парижской полиции. Подлинная жизнь Франсуа Пико под пером блестящего мастера историко-приключенческого жанра превратилась в захватывающую историю об Эдмоне Дантесе, узнике замка Иф. Совершив дерзкий побег, он возвращается в родной город, чтобы свершить правосудие – отомстить тем, кто разрушил его жизнь.'),
	(22, 'Роман французского классика Александра Дюма-отца «Королева Марго» открывает знаменитую трилогию об эпохе Генриха III и Генриха IV Наваррского, которую продолжают «Графиня де Монсоро» и «Сорок пять». События романа приходятся на период религиозных войн между католиками и гугенотами. Первые шаги к трону молодого принца Генриха Наваррского, противостояние его юной супруги Марго, женщины со своеобразным характером и удивительной судьбой, и коварной интриганки – французской королевы Екатерины Медичи, придворная жизнь с ее заговорами и тайнами, кровавые события Варфоломеевской ночи – вот что составляет канву этой увлекательной книги.'),
	(23, 'Послевоенная Германия середины двадцатых годов прошлого века. Трое друзей – Готтфрид Ленц, Отто Кестер и Роберт Локамп – пытаются привыкнуть к мирной жизни после ужасов, с которыми им довелось столкнуться на фронте. Молодые мужчины открывают небольшую автомастерскую, а в свободное время проводят вечера в барах и гоняют на «Карле» – старой, но мощной колымаге.'),
	(24, 'Автогонщик Клэрфе вместо спокойного отдыха со старым другом проводит время с Лилиан. Девушка смертельно больна и является пациенткой туберкулезного санатория. Ей осталось жить совсем немного, и поэтому она начинает ценить каждое мгновение. А еще она мечтает о том, чтобы провести свои последние дни ярко и незабываемо.'),
	(25, 'Жажда маленьких побед, безнадежность, ненависть и горячие чувства. То пик наслаждения, то лавина отчаяния… Удивительный роман о глубине и красоте человеческих взаимоотношений, которые приводят к трагедии. Поспешите купить культовое издание и наслаждайтесь его прочтением!'),
	(26, 'Роман «Зулейха открывает глаза» начинается зимой 1930 года в глухой татарской деревне. Крестьянку Зулейху вместе с сотнями других переселенцев отправляют в вагоне-теплушке по извечному каторжному маршруту в Сибирь.'),
	(27, 'Чертоги разума. Убей в себе идиота!» – научно-популярная книга Андрей Курпатова, объясняющая в доступной читателю форме основные принципы работы мозга и рассказывающая о методах улучшения качества жизни. Автор отвечает на актуальные сегодня вопросы о цифровой зависимости, структурах мышления человека XXI века и чувстве постоянного одиночества.'),
	(28, 'Их четверо. Летчик из Анадыря; знаменитый искусствовед; шаманка из алтайского села; модная московская художница. У каждого из них своя жизнь, но возникает внештатная ситуация, и эти четверо собираются вместе. Точнее – их собирают для выполнения задания!.. В тамбовской библиотеке умер директор, а вслед за этим происходят странные события – библиотека разгромлена, словно в ней пытались найти все сокровища мира, а за сотрудниками явно кто-то следит. Что именно было спрятано среди книг?.. И отчего так важно это найти?..'),
	(29, 'Волна страшных убийств захватила небольшой американский город Дерри. Один за одним погибают дети, но полиция бессильна. Маньяк не оставляет следов, нет ни единой зацепки.'),
	(30, 'Новая версия романа «Противостояние», с которым читатели познакомились в 1978 году. На этот раз захватывающая история мутации вируса гриппа и ужасающих последствий дополнена подробностями и разъяснениями действий героев, ранее неизвестными гранями характеров и более развернутой сюжетной линией.'),
	(31, 'Писатель Джек Торренс устраивается на зиму работать смотрителем роскошного отеля «Оверлук», расположенного вблизи снежных горных вершин. Для мужчины это – отличная возможность закончить работу над своим романом, а еще провести время с женой и сыном.'),
	(32, '«О дивный новый мир» – изысканная и остроумная антиутопия о генетически программируемом «обществе потребления», в котором разворачивается трагическая история Дикаря – «Гамлета» этого мира.'),
	(33, 'Американский романист Теодор Драйзер давно занял почетное место среди классиков мировой литературы. Тема большого бизнеса, людей, как преуспевших в нем, так и потерпевших фиаско, привлекала внимание Т. Драйзера еще в те годы, когда он занимался журналистикой.'),
	(34, 'Роман «Американская трагедия» – вершина творчества выдающегося американского писателя Теодора Драйзера. Он говорил: «Никто не создает трагедий – их создает жизнь. Писатели лишь изображают их». Драйзеру удалось так талантливо изобразить трагедию Клайва Грифитса, что его история не оставляет равнодушным и современного читателя. Молодой человек, вкусивший всю прелесть жизни богатых, так жаждет утвердиться в их обществе, что идет ради этого на преступление.'),
	(35, 'Порфирий Петрович – полицейско-литературный робот. Он раскрывает убийства, допрашивает свидетелей, а вместо сухих отчетов о проведенном расследовании пишет захватывающие романы. Книги Порфирия Петровича расходятся на ура, чему невероятно радуется его начальство. Ведь самоокупаемость для Полицейского Управления – дело чрезвычайной важности.'),
	(36, 'Утопический роман, который разошелся тиражом в 150 000 экземпляров. История боевого пилота и художника Дамилолы Карпова, жителя офшора Бизантиум, и Грыма, выпускника школы оркской столицы Славы. Судьбы героев магическим образом связали любовь, война и интрига, которую затеяла Кая, чтобы достичь личных целей.'),
	(37, 'Утопический роман, который разошелся тиражом в 150 000 экземпляров. История боевого пилота и художника Дамилолы Карпова, жителя офшора Бизантиум, и Грыма, выпускника школы оркской столицы Славы. Судьбы героев магическим образом связали любовь, война и интрига, которую затеяла Кая, чтобы достичь личных целей.'),
	(38, 'Иннокентий Платонов приходит в себя в больничной палате. В голове – лишь обрывки воспоминаний и никакой целостной картины. Кто он? Как здесь оказался? Медперсонал на его вопросы не отвечает: пациенту нужен покой. Но о каком покое может идти речь, когда в сознании царит хаос из мыслей и ощущений, похожих на разрозненные фрагменты причудливой мозаики?'),
	(39, 'Книга, ставшая абсолютным бестселлером! Захватывающая, предельно откровенная и пронзительная история, главную идею которой можно уложить в два коротких слова: «Не навреди». Каково это – быть ответственным за жизнь и здоровье человека? Где черпают силы люди, от которых зависит так много? Всемирно известный британский нейрохирург Генри Марш завораживающе рассказывает о своих буднях, о работе, о выборе, за кого из пациентов бороться, а кого отпустить.');

INSERT INTO countries_books(book_id, country) VALUES
	(1, 'Россия'),
	(2, 'Россия'),
	(3, 'Россия'),
	(4, 'США'),
	(5, 'США'),
	(6, 'Франция'),
	(6, 'Англия'),
	(7, 'Италия'),
	(7, 'Швейцария'),
	(7, 'Ватикан'),
	(7, 'США'),
	(8, 'США'),
	(9, 'Италия'),
	(10, 'Испания'),
	(10, 'США'),
	(11, 'Англия'),
	(12, 'Англия'),
	(13, 'Англия'),
	(14, 'Англия'),
	(15, 'Россия'),
	(16, 'Россия'),
	(17, 'Россия'),
	(17, 'Германия'),
	(17, 'Польша'),
	(18, 'Россия'),
	(18, 'Германия'),
	(18, 'Польша'),
	(19, 'Россия'),
	(20, 'Швейцария'),
	(21, 'Франция'),
	(22, 'Франция'),
	(23, 'Германия'),
	(24, 'Германия'),
	(25, 'Франция'),
	(26, 'Татарстан'),
	(28, 'Россия'),
	(29, 'США'),
	(30, 'США'),
	(31, 'США'),
	(32, 'Англия'),
	(33, 'США'),
	(34, 'США'),
	(35, 'Россия'),
	(36, 'Россия'),
	(38, 'Россия'),
	(35, 'Англия');

INSERT INTO rating(user_id, book_id, assessment_id) VALUES 
	(1, 1, 6), (1, 3, 9), (1, 30, 8),
	(2, 2, 10), (2, 4, 7), (2, 1, 9), (2, 5, 8),
	(3, 1, 8), (3, 2, 9), (3, 14, 4),
	(4, 1, 8), (4, 13, 9), (4, 17, 10), (4, 20, 9),
	(5, 20, 8), (5, 19, 9), (5, 16, 8),
	(6, 11, 3),
	(7, 11, 9), (7, 4, 6), (7, 12, 8),
	(8, 9, 10), (8, 14, 7),
	(9, 1, 4), (9, 23, 10), (9, 24, 8), (9, 25, 8),
	(10, 2, 4), (10, 27, 8), (10, 31, 9), (10, 33, 8), (10, 35, 10),
	(11, 3, 7), (11, 9, 8), (11, 33, 8), (11, 4, 7),
	(12, 13, 6), (12, 24, 2), (12, 19, 9),
	(13, 7, 9), (13, 4, 8),
	(14, 29, 7), (14, 22, 8), (14, 27, 9),
	(15, 35, 5), (15, 36, 9),
	(16, 6, 9), (16, 31, 8),
	(17, 28, 6), (17, 5, 1),
	(18, 34, 4), (18, 38, 8), (18, 37, 9),
	(19, 1, 4), (19, 35, 7),
	(20, 2, 4), (20, 3, 9), (20, 4, 8), (20, 34, 4),
	(21, 3, 4), (21, 4, 5), (21, 5, 4),
	(22, 17, 8), (22, 15, 9), (22, 11, 4),
	(23, 11, 7), (23, 14, 10),
	(24, 16, 7), (24, 19, 8), (24, 21, 9),
	(25, 14, 6), (25, 32, 9),
	(26, 8, 5),
	(27, 36, 9),
	(28, 33, 7),
	(35, 1, 6),
	(40, 30, 9),
	(50, 17, 7),
	(55, 18, 8),
	(60, 7, 7),
	(70, 29, 10);

INSERT INTO reviews(book_id, user_id, review) VALUES
	(1, 4, 'Очень интересная книга'), 
	(4, 3, 'Я ожидал большего'), 
	(7, 8, 'На одном дыхании читается'), 
	(19, 65, 'Прочту все книги из серии, очень понравилась.'), 
	(7, 19, 'Нудно.'), 
	(19, 90, 'Не смог дочитать, слишком скучно'), 
	(30, 3, 'Классно, меняет мировоззрение.'), 
	(19, 9, 'Я потрясен.')

-- Индексы -------------
CREATE INDEX books_name_idx ON books(name);
CREATE INDEX authors_last_name_first_name_idx ON authors(last_name, first_name);
CREATE INDEX rating_user_id_idx ON rating(user_id);
CREATE INDEX reviews_user_id_idx ON reviews(user_id);
-- ---------------------
-- Представления--------
-- Лучшие книги
CREATE VIEW best_books AS SELECT name, ROUND(avg(assessment_id), 1) as rating FROM books
	JOIN rating
	ON books.id = rating.book_id
	GROUP BY book_id
	ORDER BY rating DESC
	LIMIT 10;

SELECT * FROM best_books;

-- Страны, в которых проходили действия книг
DROP VIEW countries_b;
SELECT * FROM best_books;
CREATE VIEW countries_b AS SELECT countries_books.country, GROUP_CONCAT(name SEPARATOR ', ') as books FROM countries_books JOIN books
ON books.id = countries_books.book_id
GROUP BY country;

SELECT * FROM countries_b;
-- ---------------------
-- Процедура------------
-- Определение рейтинга выбранной книги
DELIMITER //
CREATE PROCEDURE rating(IN book VARCHAR(50)) 
BEGIN 
	SELECT name, ROUND(avg(assessment_id), 1) FROM rating JOIN books ON books.id = rating.book_id GROUP BY book_id HAVING name = book; 
END//
DELIMITER ;
CALL rating('Атлант расправил плечи');

-- Триггер--------------
-- Триггер, обновляющий в таблице books итоговый рейтинг книги
-- Для этого добавим в таблицу books новый столбец rating
ALTER TABLE books ADD rating FLOAT(1) UNSIGNED;

DELIMITER //
CREATE TRIGGER books_rating AFTER INSERT ON rating
FOR EACH ROW
BEGIN
	UPDATE books SET rating = (
			SELECT ROUND(avg(assessment_id), 1) 
			FROM rating 
			GROUP BY book_id 
			HAVING book_id = (
				SELECT book_id 
					FROM rating 
					WHERE id = (SELECT max(id) FROM rating)))
	WHERE id = (SELECT book_id FROM rating WHERE id = (SELECT max(id) FROM rating));
END//

DELIMITER ;
DROP TRIGGER books_rating;
SELECT * FROM books;

-- ----------------------
-- ------------------------------------------------------------
-- 1. Книг какого жанра больше всего?
-- 2. Авторы, книги которых входят в ТОП-10 в рейтинге
-- 3. Книги, действия которых происходят в Америке в 20 веке
-- 4. Самый молодой пользователь из самых активных.
-- 5. Какого жанра книги, объем которых переваливает 1000 страниц

-- 1.
SELECT (SELECT genre FROM genres WHERE genres.id = bg.genre_id) as genre, count(genre_id) as kolvo
FROM books_genres bg
GROUP BY bg.genre_id
ORDER BY kolvo DESC
LIMIT 1;

-- 2.
SELECT CONCAT(first_name, ' ', last_name)
FROM 
	(SELECT first_name, last_name, ROUND(avg(assessment_id), 1) as assessment
	FROM rating
	JOIN books ON rating.book_id = books.id
	JOIN authors ON books.author_id = authors.id
	GROUP BY book_id
	ORDER BY assessment DESC
	LIMIT 10) as rating;

-- 3.
SELECT name
FROM countries_books cb
JOIN books_century
ON cb.book_id = books_century.book_id
JOIN books
ON cb.book_id =books.id
WHERE country = 'США' AND century_id = 20;
	
-- 4.
-- Активных пользователей определим по количеству поставленных оценок и отзывов
SELECT users.id, CONCAT(first_name, ' ', last_name), birthday, kolvo_assess
FROM
	(SELECT users.id, rating.user_id, first_name, last_name, count(rating.user_id) + count(DISTINCT reviews.user_id) as kolvo_assess,
		(SELECT birthday FROM profiles WHERE profiles.user_id = rating.user_id) as birthday
		FROM users
			JOIN profiles
			ON users.id = profiles.user_id
			JOIN rating
			ON profiles.user_id = rating.user_id
			LEFT JOIN reviews
			ON reviews.user_id = users.id
		GROUP BY rating.user_id
		ORDER BY kolvo_assess DESC
		LIMIT 10
	) as users
ORDER BY birthday DESC;

-- 5.
SELECT genre, subgenre, name, volume
FROM books b2
JOIN books_genres bg
ON b2.id = bg.book_id
JOIN books_subgenres bs
ON b2.id = bs.book_id
JOIN genres
ON genres.id = bg.genre_id
JOIN subgenres
ON subgenres.id = bs.subgenre_id
WHERE volume >= 1000;

	